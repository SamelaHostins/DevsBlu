
package model;


public enum Setores {
   
  OPERACIONAL, FINANCEIRO, ADMINISTRATIVO, RECURSOSHUMANOS, COMERCIAL;  
    
}
