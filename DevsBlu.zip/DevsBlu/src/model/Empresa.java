
package model;

import java.util.ArrayList;


public class Empresa {
    
    private Setores setores;
    private RespostaFamilia respostaFamilia;
    private RespostaDuasDoses respostaDuasDoses;
    private RespostaTrocaDeMascara respostaTrocaDeMascara;
    private Vacinas vacinas;
    private String NomeEmpresa;
    private int NumeroDeFunc;
    private ArrayList<Funcionarios> funcionarios = new ArrayList<>();
    
    /**
     * Retorna o tipo de Setor em que o funcionario trabalha
     * @return O tipo de Setor
     */
    public Setores getSetores() {
        return setores;
    }

    public void setSetores(Setores setores) {
        this.setores = setores;
    }
    
    /**
     * Retorna a resposta se o funcionario ja tomou as duas doses
     * @return a resposta
     */
    public RespostaDuasDoses getRespostaDuasDoses() {
        return respostaDuasDoses;
    }

    public void setRespostaDuasDoses(RespostaDuasDoses respostaDuasDoses) {
        this.respostaDuasDoses = respostaDuasDoses;
    }

    /**
     * Retorna a resposta se o funcionario troca de mascara de 3 em 3 horas
     * @return a resposta
     */
    public RespostaTrocaDeMascara getRespostaTrocaDeMascara() {
        return respostaTrocaDeMascara;
    }

    public void setRespostaTrocaDeMascara(RespostaTrocaDeMascara respostaTrocaDeMascara) {
        this.respostaTrocaDeMascara = respostaTrocaDeMascara;
    }
    
    /**
     * Retorna a resposta se os familiares que moram com o funcionario ja se vacinaram
     * @return A resposta
     */
    public RespostaFamilia getRespostaFamilia() {
        return respostaFamilia;
    }

    public void setRespostaFamilia(RespostaFamilia respostaFamilia) {
        this.respostaFamilia = respostaFamilia;
    }
    
    /**
     * Retorna o tipo de Vacina tomada
     * @return O tipo de Vacina tomada
     */
    public Vacinas getVacinas() {
        return vacinas;
    }

    public void setVacinas(Vacinas vacinas) {
        this.vacinas = vacinas;
    }
    
    /**
     * Retorna o nome da empresa
     * @return O nome da empresa
     */
    public String getNomeEmpresa() {
        return NomeEmpresa;
    }

    public void setNomeEmpresa(String NomeEmpresa) {
        this.NomeEmpresa = NomeEmpresa;
    }

    /**
     * Retorna o numero de funcionarios que trabalham na empresa
     * @return O numero de funcionarios
     */
    public int getNumeroDeFunc() {
        return NumeroDeFunc;
    }

    public void setNumeroDeFunc(int NumeroDeFunc) {
        this.NumeroDeFunc = NumeroDeFunc;
    }

    /**
     * Retorna todos os dados que o ArrayList contém 
     * @return Todos os dados que o ArrayList contém
     */
    public ArrayList<Funcionarios> getFuncionarios() {
        return funcionarios;
    }
    
    /**
     * Inclui cada um dos Funcionarios no ArrayList
     * @param f A informação contida nele será incluida no ArrayList
     */
    public void incluirFuncionarios(Funcionarios f){
        funcionarios.add(f);
    }
    
    /**
     * Este metodo RespostaFamilia identificarRespostaFamilia(), define a partir do 
     * enum RespostaFamilia, o tipo de resposta do funcionario, ou seja,
     * retorna Sim ou Nao.
     * @return A resposta se os familiares que moram com o funcionario ja se vacinaram.
     */
    public RespostaFamilia identificarRespostaFamilia(){   
        if(getRespostaFamilia() == RespostaFamilia.SIM){
          return RespostaFamilia.SIM;  
        }else{
            if(getRespostaFamilia() == RespostaFamilia.NAO){
          return RespostaFamilia.NAO;        
        }else{
            return null;
            }}}
    
     /**
     * Este metodo RespostaDuasDoses identificarRespostaDoses(), define a partir do 
     * enum RespostaDuasDoses, o tipo de resposta do funcionario, ou seja,
     * retorna Sim2 ou Nao2.
     * @return A resposta se o funcionario ja tomou as duas doses.
     */
    public RespostaDuasDoses identificarRespostaDoses(){   
        if(getRespostaDuasDoses() == RespostaDuasDoses.SIM2){
          return RespostaDuasDoses.SIM2;  
        }else{
            if(getRespostaDuasDoses() == RespostaDuasDoses.NAO2){
          return RespostaDuasDoses.NAO2;        
        }else{
            return null;
            }}}
        
    /**
     * Este metodo RespostaTrocaDeMascara identificarTroca(), define a partir do 
     * enum RespostaTrocaDeMascara, o tipo de resposta do funcionario, ou seja,
     * retorna Sim1 ou Nao1.
     * @return A resposta se o funcionario costuma trocar de mascara de 3 em 3 horas.
     */
    public RespostaTrocaDeMascara identificarTroca(){   
        if(getRespostaTrocaDeMascara() == RespostaTrocaDeMascara.SIM1){
          return RespostaTrocaDeMascara.SIM1;  
        }else{
            if(getRespostaTrocaDeMascara() == RespostaTrocaDeMascara.NAO1){
          return RespostaTrocaDeMascara.NAO1;        
        }else{
            return null;
            }}}
    
    /**
     * Este metodo Vacinas identificarVacina(), define a partir do 
     * enum Vacinas, o tipo de Vacina que o funcionario tomou, ou seja,
     * se ele a AstraZeneca, Pfizer, Janssen, ou Outra.
     * @return O tipo de Vacina tomada.
     */      
    public Vacinas identificarVacina(){   
        if(getVacinas() == Vacinas.ASTRAZENECA){
          return Vacinas.ASTRAZENECA;  
        }else{
            if(getVacinas() == Vacinas.PFIZER){
          return Vacinas.PFIZER;
        }else{
            if(getVacinas() == Vacinas.JANSSEN){
          return Vacinas.JANSSEN;
        }else{
            if(getVacinas() == Vacinas.OUTRA){
          return Vacinas.OUTRA;          
        }else{
            return null;
}}}}}

    /**
     * Este metodo Setores identificarSetor(), define a partir do 
     * enum Setores, o tipo de Setor que o funcionario trabalha, ou seja,
     * se ele trabalha no Administrativo, Comercial, Financeiro, Operacional
     * ou no Recursos Humanos.
     * @return O tipo de Setor que o funcionario trabalha.
     */  
    public Setores identificarSetor(){   
        if(getSetores() == Setores.ADMINISTRATIVO){
          return Setores.ADMINISTRATIVO;  
        }else{
            if(getSetores() == Setores.COMERCIAL){
          return Setores.COMERCIAL;  
        }else{
            if(getSetores() == Setores.FINANCEIRO){
          return Setores.FINANCEIRO;  
        }else{
            if(getSetores() == Setores.OPERACIONAL){
          return Setores.OPERACIONAL; 
        }else{
            if(getSetores() == Setores.RECURSOSHUMANOS){
          return Setores.RECURSOSHUMANOS; 
        }else{
            return null;
    }}}}}}
}
