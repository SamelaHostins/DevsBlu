
package model;


public enum RespostaTrocaDeMascara {
    SIM1, NAO1;
}
