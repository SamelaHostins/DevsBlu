
package model;


public enum RespostaFamilia {
    
    SIM, NAO;
}
