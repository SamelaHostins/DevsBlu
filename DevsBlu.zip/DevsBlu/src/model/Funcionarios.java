
package model;

import java.time.LocalDate;


public class Funcionarios extends Empresa implements Comparable<Funcionarios>{
    
    private String nomeFuncionario;
    private LocalDate dataDosTipos;
    private Vacinas vacinas;

    /**
     * Retorna o nome do funcionario
     * @return O nome do funcionario
     */
    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }
    
    /**
     * Retorna a data em que o funcionario tomou a vacina
     * @return A data em que o funcionario tomou a vacina
     */
    public LocalDate getDataDosTipos() {
        return dataDosTipos;
    }

    public void setDataDosTipos(LocalDate dataDosTipos) {
        this.dataDosTipos = dataDosTipos;
    }

    /**
     * Retorna o tipo de Vacina tomada
     * @return O tipo de Vacina tomada
     */
    public Vacinas getVacinas() {
        return vacinas;
    }

    public void setVacinas(Vacinas vacinas) {
        this.vacinas = vacinas;
    }
    
    /**
     * Compara os Funcionarios conforme a data em que tomaram as vacinas, da
     * menor para a maior.
     * @param o Dado passado para o metodo que trabalhara com essa informacao
     * @return A comparacao entre as datas de cada lancamento
     */
     public int compareTo(Funcionarios o) {
    return this.dataDosTipos.compareTo(o.getDataDosTipos());
    }
  
    /**
     * Retorna a representacao String do objeto
     * @return A representacao String do objeto
     */
    public String toString() {
        return  getNomeFuncionario() + " foi vacinado(a) com " + vacinas + " na data " + dataDosTipos;
    } 
}
