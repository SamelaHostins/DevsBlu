
package model;


public enum Vacinas {
  
 ASTRAZENECA, PFIZER, JANSSEN, OUTRA;   
    
    
}
