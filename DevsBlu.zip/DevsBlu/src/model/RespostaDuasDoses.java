
package model;


public enum RespostaDuasDoses {
    
    SIM2, NAO2;
}
