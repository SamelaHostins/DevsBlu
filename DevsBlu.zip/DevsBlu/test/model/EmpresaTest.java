
package model;

import java.time.LocalDate;
import org.junit.Test;
import static org.junit.Assert.*;


public class EmpresaTest {
    
    public EmpresaTest() {
    }

    
    @Test
    public void testIncluirNoArray() {
        
        Empresa c = new Empresa();
        
        Funcionarios t = new Funcionarios();
        t.setNomeFuncionario("Julia");
        t.setDataDosTipos(LocalDate.of(2010,10,20));
        t.setVacinas(Vacinas.ASTRAZENECA);
        c.incluirFuncionarios(t);
     
      assertEquals(1, c.getFuncionarios().size());
    }
    
    @Test
    public void RetornandoFuncionariosNaoVacinados() {
        
        Empresa c = new Empresa();
        c.setNumeroDeFunc(500);
        
        Funcionarios t = new Funcionarios();
            t.setNomeFuncionario("Julia");
            t.setDataDosTipos(LocalDate.of(2010,10,20));
            t.setVacinas(Vacinas.ASTRAZENECA);
            c.incluirFuncionarios(t); 
            
        Funcionarios t2 = new Funcionarios();
            t2.setNomeFuncionario("Nathan");
            t2.setDataDosTipos(LocalDate.of(2010,11,20));
            t2.setVacinas(Vacinas.JANSSEN);
            c.incluirFuncionarios(t2); 
   
       int faltaVacinar;
        faltaVacinar = c.getNumeroDeFunc() - c.getFuncionarios().size();
         assertEquals(498, faltaVacinar, 0.01);
    }
    
    @Test
    public void testIdentificarVacina() {
        
        Empresa c = new Empresa();
        
        Funcionarios t = new Funcionarios();
            t.setNomeFuncionario("Julia da Costa");
            t.setDataDosTipos(LocalDate.of(2010,10,20));
            t.setVacinas(Vacinas.ASTRAZENECA);
            c.incluirFuncionarios(t); 
            
        Funcionarios t2 = new Funcionarios();
            t2.setNomeFuncionario("Nathan Tonet");
            t2.setDataDosTipos(LocalDate.of(2010,11,20));
            t2.setVacinas(Vacinas.JANSSEN);
            c.incluirFuncionarios(t2);  
             
       Funcionarios t3 = new Funcionarios();
            t3.setNomeFuncionario("Sofia Oliveiria");
            t3.setDataDosTipos(LocalDate.of(2010,12,20));
            t3.setVacinas(Vacinas.PFIZER);
            c.incluirFuncionarios(t3); 
            
        Funcionarios t4 = new Funcionarios();
            t4.setNomeFuncionario("Eliza Junkes");
            t4.setDataDosTipos(LocalDate.of(2010,9,20));
            t4.setVacinas(Vacinas.OUTRA);
            c.incluirFuncionarios(t4);                    
             
             Empresa m;
             m = c.getFuncionarios().get(0);
                assertEquals(Vacinas.ASTRAZENECA, m.identificarVacina());
    
             m = c.getFuncionarios().get(1);
                assertEquals(Vacinas.JANSSEN, m.identificarVacina()); 
                
             m = c.getFuncionarios().get(2);
                assertEquals(Vacinas.PFIZER, m.identificarVacina());
                
             m = c.getFuncionarios().get(3);
                assertEquals(Vacinas.OUTRA, m.identificarVacina());             
               
    }

    @Test
    public void testIdentificarSetor() {
        
        Empresa c = new Empresa();
        
        Funcionarios t = new Funcionarios();
            t.setNomeFuncionario("Julia da Costa");
            t.setDataDosTipos(LocalDate.of(2010,10,20));
            t.setSetores(Setores.FINANCEIRO);
            c.incluirFuncionarios(t); 
            
        Funcionarios t2 = new Funcionarios();
            t2.setNomeFuncionario("Nathan Tonet");
            t2.setDataDosTipos(LocalDate.of(2010,11,20));
            t2.setSetores(Setores.ADMINISTRATIVO);
            c.incluirFuncionarios(t2); 

        Funcionarios t3 = new Funcionarios();
            t3.setNomeFuncionario("Sofia Oliveiria");
            t3.setDataDosTipos(LocalDate.of(2010,12,20));
            t3.setSetores(Setores.COMERCIAL);
            c.incluirFuncionarios(t3); 
            
        Funcionarios t4 = new Funcionarios();
            t4.setNomeFuncionario("Sâmela Hostins");
            t4.setDataDosTipos(LocalDate.of(2010,9,20));
            t4.setSetores(Setores.OPERACIONAL);
            c.incluirFuncionarios(t4); 
    
        Funcionarios t5 = new Funcionarios();
            t5.setNomeFuncionario("Eliza Junkes");
            t5.setDataDosTipos(LocalDate.of(2010,8,20));
            t5.setSetores(Setores.RECURSOSHUMANOS);
            c.incluirFuncionarios(t5);    
            
         Empresa m;
             m = c.getFuncionarios().get(0);
                assertEquals(Setores.FINANCEIRO, m.identificarSetor());
    
             m = c.getFuncionarios().get(1);
                assertEquals(Setores.ADMINISTRATIVO, m.identificarSetor()); 
                
             m = c.getFuncionarios().get(2);
                assertEquals(Setores.COMERCIAL, m.identificarSetor());
                
             m = c.getFuncionarios().get(3);
                assertEquals(Setores.OPERACIONAL, m.identificarSetor());   
                
             m = c.getFuncionarios().get(4);
                assertEquals(Setores.RECURSOSHUMANOS, m.identificarSetor());   
}

    @Test
    public void testIdentificarRespostaFamilia() {
        
       Empresa c = new Empresa(); 
        
        Funcionarios t = new Funcionarios();
            t.setNomeFuncionario("Julia da Costa");
            t.setDataDosTipos(LocalDate.of(2010,10,20));
            t.setRespostaFamilia(RespostaFamilia.NAO);
            c.incluirFuncionarios(t); 
            
        Funcionarios t2 = new Funcionarios();
            t2.setNomeFuncionario("Nathan Tonet");
            t2.setDataDosTipos(LocalDate.of(2010,11,20));
            t2.setRespostaFamilia(RespostaFamilia.SIM);
            c.incluirFuncionarios(t2); 
        
        Empresa m;
             m = c.getFuncionarios().get(0);
                assertEquals(RespostaFamilia.NAO, m.identificarRespostaFamilia());
    
             m = c.getFuncionarios().get(1);
                assertEquals(RespostaFamilia.SIM, m.identificarRespostaFamilia());
    }

    @Test
    public void testIdentificarRespostaDoses() {
        
       Empresa c = new Empresa(); 
        
        Funcionarios t = new Funcionarios();
            t.setNomeFuncionario("Julia da Costa");
            t.setDataDosTipos(LocalDate.of(2010,10,20));
            t.setRespostaDuasDoses(RespostaDuasDoses.SIM2);
            c.incluirFuncionarios(t); 
            
        Funcionarios t2 = new Funcionarios();
            t2.setNomeFuncionario("Nathan Tonet");
            t2.setDataDosTipos(LocalDate.of(2010,11,20));
            t2.setRespostaDuasDoses(RespostaDuasDoses.NAO2);
            c.incluirFuncionarios(t2); 
        
        Empresa m;
             m = c.getFuncionarios().get(0);
                assertEquals(RespostaDuasDoses.SIM2, m.identificarRespostaDoses());
    
             m = c.getFuncionarios().get(1);
                assertEquals(RespostaDuasDoses.NAO2, m.identificarRespostaDoses());
    }
    
    @Test
    public void testIdentificarTroca() {
        
               Empresa c = new Empresa(); 
        
        Funcionarios t = new Funcionarios();
            t.setNomeFuncionario("Julia da Costa");
            t.setDataDosTipos(LocalDate.of(2010,10,20));
            t.setRespostaTrocaDeMascara(RespostaTrocaDeMascara.NAO1);
            c.incluirFuncionarios(t); 
            
        Funcionarios t2 = new Funcionarios();
            t2.setNomeFuncionario("Nathan Tonet");
            t2.setDataDosTipos(LocalDate.of(2010,11,20));
            t2.setRespostaTrocaDeMascara(RespostaTrocaDeMascara.SIM1);
            c.incluirFuncionarios(t2); 
        
        Empresa m;
             m = c.getFuncionarios().get(0);
                assertEquals(RespostaTrocaDeMascara.NAO1, m.identificarTroca());
    
             m = c.getFuncionarios().get(1);
                assertEquals(RespostaTrocaDeMascara.SIM1, m.identificarTroca());
        
    }
}
